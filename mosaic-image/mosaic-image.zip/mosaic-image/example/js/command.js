$(document).ready(function(){
	
	$(".mosaic-container").imageMosaic({cell: 4, marginl: 10, marginb: 10});
	
});